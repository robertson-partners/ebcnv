<div class="notice-info notice">
	<p>
		<strong><?php _e( 'Obsolete Addons Detected', 'amazon-s3-and-cloudfront' ); ?></strong> &mdash;
		<?php _e( 'Please remove the following obsolete addons:', 'amazon-s3-and-cloudfront' ); ?>
	</p>

	<?php echo $plugins; ?>

	<p>
		<?php _e( 'Integrations are now included in the core WP Offload Media plugin. Once these addons are removed this message will go away.', 'amazon-s3-and-cloudfront' ); ?>
	</p>
</div>