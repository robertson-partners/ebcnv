<div class="as3cf-content as3cf-error fatal">
	<div class="error inline as3cf-error">
		<p><?php echo $message; // xss ok ?></p>
	</div>
</div>